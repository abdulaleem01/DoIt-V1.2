import React from 'react'

function NewTest(props) {
  return (
    <div>{props.idd}</div>
  )
}

export default NewTest